from gym.envs.registration import register
from pathlib import Path
# TODO: need to change when we use different building type
# parameter for citylearn
climate_zone = 4
data_path = Path("citylearn/envs/data/Climate_Zone_"+str(climate_zone))
building_attributes = data_path / 'building_attributes.json'
weather_file = data_path / 'weather_data.csv'
solar_profile = data_path / 'solar_generation_1kW.csv'
building_state_actions = 'citylearn/envs/buildings_state_action_space.json'
building_id = ["Building_1"]
objective_function = ['ramping','1-load_factor','average_daily_peak',\
                    'peak_demand','net_electricity_consumption','quadratic']
# register an city_learn envirnoment
# TODO might need to change max_episode_Steps
register(
    id='citylearn-v0',
    entry_point='citylearn.envs:CityLearn',
    max_episode_steps=150,
    kwargs={'data_path' : data_path, 'building_attributes' : building_attributes, \
        'weather_file' : weather_file, 'solar_profile': solar_profile, 'building_ids': building_id,\
            "buildings_states_actions":building_state_actions, "simulation_period":(0,8759),\
                "cost_function":objective_function},
)
# register(
#     id='citylearn-v0',
#     entry_point='citylearn.envs:CityLearn',
# )